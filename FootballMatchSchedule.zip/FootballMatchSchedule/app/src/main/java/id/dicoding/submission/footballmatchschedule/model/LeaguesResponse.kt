package id.dicoding.submission.footballmatchschedule.model

data class LeaguesResponse(val leagues: List<League>)