package id.dicoding.submission.footballmatchschedule.model

data class TeamsResponse(val teams: List<Team>)