package id.dicoding.submission.footballmatchschedule.constant

//https://blog.egorand.me/where-do-i-put-my-constants-in-kotlin/
class Constant {
    companion object {
        @JvmField
        val DAY_IN_INDONESIAN = arrayOf("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
        @JvmField
        val MONT_IN_INDONESIAN = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
    }
}