package id.dicoding.submission.footballmatchschedule.model

data class MatchesResponse(val events: List<Match>)